package com.osttra.tradeMatching.constant;

public class StatusEnum {
	//defining the 4 values of Status Enum 
	
	public enum Status {
						Confirmed,
						Unconfirmed,
						Cancel,
						Exit 
						}  
	
}
