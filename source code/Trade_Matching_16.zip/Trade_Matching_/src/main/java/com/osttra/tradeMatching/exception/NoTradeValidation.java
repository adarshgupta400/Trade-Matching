package com.osttra.tradeMatching.exception;

public class NoTradeValidation  extends Exception{
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NoTradeValidation(String message) {
		super(message);
	}
}
